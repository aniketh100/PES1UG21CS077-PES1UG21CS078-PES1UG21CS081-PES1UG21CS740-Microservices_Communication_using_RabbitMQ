
docker run -d -it --rm --name rabbitmq -p 5672:5672 -p 15672:15672 rabbitmq:3-management       /*******LET IT RUN for 30 seconds before any other command********/

go to sql folder and run the following commands:
    docker network create app_network
    docker-compose up -d
    docker exec -it mysql_container bash
    cd data
    mysql -uroot -p2002
    grant all privileges on *.* to 'root'@'%' with grant option;
    flush privileges;
    source ./run.sql;
    exit


go out of the sql folder and run the following commands:

    ipconfig get ur ethernet ip address and copy it
    replace it in the required places in the docker-compose.yml 
    docker-compose up -d


open browser and go to localhost:5000 and enjoy :)





