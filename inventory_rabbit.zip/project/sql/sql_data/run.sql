USE student_project;

CREATE TABLE INVENTORY_MANAGEMENT(
    name VARCHAR(50),
    item_id VARCHAR(15),
    qty INT(5)
);